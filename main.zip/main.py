from flask import Flask, render_template
main = Flask(__name__)

@main.route('/')
def index():
    return render_template('index.html')
    # return 'Hello, World!'

@main.route('/index.html')
def home():
    return render_template('index.html')

@main.route('/linux.html')
def linux():
    return render_template('linux.html')
    # return 'Hello, World!'

@main.route('/automation.html')
def automation():
    return render_template('automation.html')

@main.route('/c.html')
def c():
    return render_template('c.html')

@main.route('/camera.html')
def camera():
    return render_template('camera.html')

@main.route('/cplus.html')
def cplus():
    return render_template('cplus.html')

@main.route('/os.html')
def os():
    return render_template('os.html')

if __name__=="__main__":
    main.run(debug=True, port=7000)